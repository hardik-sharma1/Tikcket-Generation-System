package com.tcs.bean;

import java.util.Date;
public class  Ticket_info{
	
	private Integer ticket_id;
	private Integer uploader_id;
	private String uploader_name;
	private String ticket_heading;
	private String ticket_query;
	private String status;
	private Date upload_time;
	private String approver_id;
	private String approver_name;	
	private Date approved_time;
	private String system_ip;
	
		
	public String getSystem_ip() {
		return system_ip;
	}
	public void setSystem_ip(String system_ip) {
		this.system_ip = system_ip;
	}
	public Integer getTicket_id() {
		return ticket_id;
	}
	public void setTicket_id(Integer ticket_id) {
		this.ticket_id = ticket_id;
	}
	public Integer getUploader_id() {
		return uploader_id;
	}
	public void setUploader_id(Integer uploader_id) {
		this.uploader_id = uploader_id;
	}
	public String getUploader_name() {
		return uploader_name;
	}
	public void setUploader_name(String uploader_name) {
		this.uploader_name = uploader_name;
	}
	public String getTicket_heading() {
		return ticket_heading;
	}
	public void setTicket_heading(String ticket_heading) {
		this.ticket_heading = ticket_heading;
	}
	public String getTicket_query() {
		return ticket_query;
	}
	public void setTicket_query(String ticket_query) {
		this.ticket_query = ticket_query;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getUpload_time() {
		return upload_time;
	}
	public void setUpload_time(Date upload_time) {
		this.upload_time = upload_time;
	}
	public String getApprover_id() {
		return approver_id;
	}
	public void setApprover_id(String approver_id) {
		this.approver_id = approver_id;
	}
	public String getApprover_name() {
		return approver_name;
	}
	public void setApprover_name(String approver_name) {
		this.approver_name = approver_name;
	}
	public Date getApproved_time() {
		return approved_time;
	}
	public void setApproved_time(Date approved_time) {
		this.approved_time = approved_time;
	}
	@Override
	public String toString() {
		return "Ticket_info [ticket_id=" + ticket_id + ", uploader_id=" + uploader_id + ", uploader_name="
				+ uploader_name + ", ticket_heading=" + ticket_heading + ", ticket_query=" + ticket_query + ", status="
				+ status + ", upload_time=" + upload_time + ", approver_id=" + approver_id + ", approver_name="
				+ approver_name + ", approved_time=" + approved_time + "]";
	}

}
