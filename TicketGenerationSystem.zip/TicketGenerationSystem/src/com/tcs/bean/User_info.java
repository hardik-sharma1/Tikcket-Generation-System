package com.tcs.bean;

import java.util.List;

import org.springframework.stereotype.Component;


public class User_info {
	
	public List<User_info> getManagerList() {
		return managerList;
	}
	public void setManagerList(List<User_info> managerList) {
		this.managerList = managerList;
	}


	private Integer user_id;
	private String user_name;
	private String user_email;
	private String role;
	private String active_status;
	private List<User_info> managerList;
	public Integer getUser_id() {
		return user_id;
	}
	@Override
	public String toString() {
		return "User_info [user_id=" + user_id + ", user_name=" + user_name + ", user_email=" + user_email + ", role="
				+ role + ", active_status=" + active_status + "]";
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getActive_status() {
		return active_status;
	}
	public void setActive_status(String active_status) {
		this.active_status = active_status;
	}
	public User_info()
	{
		
	}
	
	
	public User_info(Integer user_id, String user_name, String user_email, String role, String active_status) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.user_email = user_email;
		this.role = role;
		this.active_status = active_status;
	}	
}
