package com.tcs.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tcs.bean.Ticket_info;
import com.tcs.bean.User_info;
import com.tcs.dao.TicketOperationDao;
import com.tcs.util.DataSource;

public class TicketOperationHandel implements TicketOperationDao{

	public boolean uploadticket(Ticket_info t) {
	

		Connection con = null;
		PreparedStatement pst = null;
		boolean status = false;
		try{
			con.setAutoCommit(false);
			con = DataSource.getConnections();
			String query = "insert into ticket_info"
			+ "(uploader_id,uploader_name,ticket_heading,ticket_query,system_ip)";
			pst  = con.prepareStatement(query);
			pst.setInt(1, 5);
			pst.setString(2,"");
			pst.setString(3,"");
			pst.setString(4,"");
			pst.setString(5,"");
			pst.execute();
			con.commit();
			status = true;
		}
		 catch(Exception e)
		{
			 try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally{
			DataSource.closeConnection(con);
			DataSource.closePreparedStatement(pst);
		}
		
		return status;
	}
	
	
	@Override
	public  List<User_info> mangerlist()
	{
		List<User_info> u = new ArrayList<User_info>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		User_info user_info = new User_info();
		try{
			con.setAutoCommit(false);
			con = DataSource.getConnections();
			String query = "select user_id,user_name from user_info where actiev_status=?"
					+ " and role in (?,?)";
			pst  = con.prepareStatement(query);
			pst.setString(1, "y");
			pst.setString(2,"tm");
			pst.setString(3,"tm");
			pst.execute();
			con.commit();
			rs = pst.getResultSet();
			while(rs.next()){
				user_info.setUser_id(rs.getInt(1));
				user_info.setUser_name(rs.getString("2"));
				u.add(user_info);
			}
			
			
		}
		 catch(Exception e)
		{
			 try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally{
			DataSource.closeConnection(con);
			DataSource.closePreparedStatement(pst);
		}
		
		return u;
	}


}
