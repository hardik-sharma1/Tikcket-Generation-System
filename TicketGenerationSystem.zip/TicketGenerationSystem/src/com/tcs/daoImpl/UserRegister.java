package com.tcs.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.tcs.bean.User_info;
import com.tcs.dao.UserRegistrationdao;
import com.tcs.util.DataSource;

public class UserRegister implements UserRegistrationdao{

	public boolean registeruser(User_info u) {
		
		Connection con = null;
		PreparedStatement pst = null;
		boolean status = false;
		try{
			con = DataSource.getConnections();
			String query = "insert into user_info(user_id,user_email,user_name,role,active_status) values(?,?,?,?,?)";
			pst  = con.prepareStatement(query);
			pst.setInt(1, u.getUser_id());
			pst.setString(2,u.getUser_email());
			pst.setString(3,u.getUser_name());
			pst.setString(4,u.getRole());
			pst.setString(5,u.getActive_status());
			pst.execute();
			status = true;
			return status;
			
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally{
			DataSource.closeConnection(con);
		}
		return status;
	}
	
	

}
