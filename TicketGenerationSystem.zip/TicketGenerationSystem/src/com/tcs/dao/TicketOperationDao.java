package com.tcs.dao;

import java.util.List;

import com.tcs.bean.Ticket_info;
import com.tcs.bean.User_info;

public interface TicketOperationDao {
	
	public boolean uploadticket(Ticket_info t);
	public List<User_info> mangerlist();

}
