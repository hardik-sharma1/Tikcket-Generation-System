package com.tcs.dao;

import com.tcs.bean.User_info;

public interface UserRegistrationdao {
	
	public boolean registeruser(User_info u);

}
