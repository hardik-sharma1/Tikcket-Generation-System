package com.tcs.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;


public class DataSource {
	
	public  static Connection getConnections()
	{
		Connection connection = null;
		try{
			Properties prop = new Properties();
			prop = PropertyFiles.getdbproperties();
			Class.forName(prop.getProperty("driver"));
			connection = (Connection) DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

		return connection;
	}
	public static void closeConnection(Connection con)
	{
		try
		{
			if(con!=null) {
				con.close();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void closePreparedStatement(PreparedStatement pst)
	{
		try
		{
			if(pst!=null) {
				pst.close();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void closeResultset(ResultSet rst)
	{
		try
		{
			if(rst!=null) {
				rst.close();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
