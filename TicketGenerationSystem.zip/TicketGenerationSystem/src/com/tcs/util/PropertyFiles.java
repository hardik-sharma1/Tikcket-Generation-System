package com.tcs.util;

import java.io.FileReader;
import java.util.Properties;


public class PropertyFiles {
	
	public static Properties getdbproperties()
	{ 
		Properties prop = new Properties();
		try {
			prop.load(new FileReader("E:/HardikNewLearning/Projects/Properties/db.properties"));
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return prop;
	}
	

}
